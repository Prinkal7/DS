#include <stdio.h>
#include <stdlib.h>

struct Node
{
int data;
struct Node *next;
};

struct Node *head = NULL;

struct Node *createNode(int data)
{
struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
newNode->data = data;
newNode->next = NULL;
return newNode;
}

void insertEnd(int data)
{
struct Node *newNode = createNode(data);

if (head == NULL)
{
head = newNode;
return;
}

struct Node *temp = head;
while (temp->next != NULL)
{
temp = temp->next;
}
temp->next = newNode;
}

void printList(struct Node *head)
{
struct Node *temp = head;
while (temp != NULL)
{
printf("%d ", temp->data);
temp = temp->next;
}
printf("\n");
}

struct Node *removeAllVal(struct Node *head, int val)
{
struct Node *curr = head;
struct Node *prev = NULL;

while (curr != NULL)
{
if (curr->data == val)
{
if (prev == NULL)
{
head = curr->next;
free(curr);
curr = head;
}
else
{
prev->next = curr->next;
free(curr);
curr = prev->next;
}
}
else
{
prev = curr;
curr = curr->next;
}
}
return head;
}

int main()
{
// Build test list: 1 -> 2 -> 6 -> 3 -> 4 -> 5 -> 6
insertEnd(1);
insertEnd(2);
insertEnd(6);
insertEnd(3);
insertEnd(4);
insertEnd(5);
insertEnd(6);

printf("Original list: ");
printList(head);

head = removeAllVal(head, 6);

printf("After removing 6: ");
printList(head);

return 0;
}

